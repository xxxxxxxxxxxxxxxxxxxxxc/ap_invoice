sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/routing/History",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/model/json/JSONModel"
], function (Controller, History, MessageToast, MessageBox, JSONModel) {
    "use strict";

    return Controller.extend("configcountry.controller.Detail", {
        onInit: function () {
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("Detail").attachPatternMatched(this._onObjectMatched, this);

            // Model for local view state and mapping data
            var oViewModel = new JSONModel({
                busy: false,
                mappings: {} // Map of docField -> odataField
            });
            this.getView().setModel(oViewModel, "viewModel");
        },

        _onObjectMatched: function (oEvent) {
            var sCountryCode = oEvent.getParameter("arguments").countryCode;
            this._sCountryCode = sCountryCode;

            // Bind the view to the country
            this.getView().bindElement({
                path: "/Countries('" + sCountryCode + "')"
            });

            // Load mapping data manually to avoid OData binding issues
            this._loadMappingData(sCountryCode);
            this._loadExistingMappings(sCountryCode);
        },

        /*
        _loadMappingData: function (sCountryCode) {
            var oTable = this.byId("mappingTable");
            oTable.setBusy(true);
            
            var oModel = this.getView().getModel();
            var that = this;

            oModel.read("/CountryFieldConfig", {
                filters: [new sap.ui.model.Filter("country_code", "EQ", sCountryCode)],
                sorters: [new sap.ui.model.Sorter("displayOrder", false)],
                success: function (oData) {
                    var aResults = oData.results;
                    var oJSONModel = new sap.ui.model.json.JSONModel({
                        items: aResults
                    });
                    oTable.setModel(oJSONModel, "mappingModel");
                    oTable.setBusy(false);
                },
                error: function (oError) {
                    oTable.setBusy(false);
                    sap.m.MessageBox.error("Error loading field mappings: " + oError.message);
                }
            });
        },
        */
        _loadMappingData: async function (sCountryCode) {
            const oTable = this.byId("mappingTable");
            oTable.setBusy(true);

            const oModel = this.getView().getModel();

            // 1. Create a list binding with filters + sorters
            const oListBinding = oModel.bindList("/CountryFieldConfig", undefined,
                [new sap.ui.model.Sorter("displayOrder", false)], // sorters
                [new sap.ui.model.Filter("country_code", "EQ", sCountryCode)] // filters
            );

            // 2. Request data (returns an array of Contexts)
            const aContexts = await oListBinding.requestContexts();

            // 3. Extract actual objects
            const aResults = aContexts.map(ctx => ctx.getObject());

            // 4. Put inside your JSON model
            const oJSONModel = new sap.ui.model.json.JSONModel({ items: aResults });
            oTable.setModel(oJSONModel, "mappingModel");

            oTable.setBusy(false);
        },

        /*
        _loadExistingMappings: function (sCountryCode) {
            var that = this;
            var oModel = this.getView().getModel();

            // Load existing mappings for this country
            oModel.read("/FieldMappings", {
                filters: [new sap.ui.model.Filter("country_code", "EQ", sCountryCode)],
                success: function (data) {
                    var mappings = {};
                    var transformations = {};
                    if (data.results) {
                        data.results.forEach(function (m) {
                            var key = m.documentAIField_fieldName + "_" + m.documentAIField_fieldType;
                            mappings[key] = m.odataField_fieldName;
                            transformations[key] = m.transformationRule;
                        });
                    }
                    that.getView().getModel("viewModel").setProperty("/mappings", mappings);
                    that.getView().getModel("viewModel").setProperty("/transformations", transformations);
                },
                error: function (err) {
                    console.error("Error loading mappings:", err);
                }
            });
        },
        */
        _loadExistingMappings: async function (sCountryCode) {
            const oModel = this.getView().getModel();

            const oListBinding = oModel.bindList("/FieldMappings", undefined, [],
                [new sap.ui.model.Filter("country_code", "EQ", sCountryCode)]
            );

            const aCtx = await oListBinding.requestContexts();
            const aData = aCtx.map(c => c.getObject());

            const mappings = {};
            const transformations = {};

            aData.forEach(m => {
                const key = m.documentAIField_fieldName + "_" + m.documentAIField_fieldType;
                mappings[key] = m.odataField_fieldName;
                transformations[key] = m.transformationRule;
            });

            const oVM = this.getView().getModel("viewModel");
            oVM.setProperty("/mappings", mappings);
            oVM.setProperty("/transformations", transformations);
        },


        onNavBack: function () {
            var oHistory = History.getInstance();
            var sPreviousHash = oHistory.getPreviousHash();

            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("RouteMain", {}, true);
            }
        },

        onUploadSchema: function () {
            this._handleFileUpload("fileUploaderSchema", "loadDocumentAISchema");
        },

        onUploadEdmx: function () {
            this._handleFileUpload("fileUploaderEdmx", "loadODataEDMX");
        },

        _handleFileUpload: function (sUploaderId, sActionName) {
            var that = this;
            var oFileUploader = this.byId(sUploaderId);
            var oFile = oFileUploader.oFileUpload.files[0];

            if (!oFile) {
                MessageToast.show("Please select a file first");
                return;
            }

            var reader = new FileReader();
            reader.onload = function (e) {
                var content = e.target.result;
                that._callAction(sActionName, content);
            };
            reader.readAsText(oFile);
        },

        /*
        _callAction: function (sActionName, sContent) {
            var that = this;
            var oModel = this.getView().getModel();
            var oPayload = {
                countryCode: this._sCountryCode
            };

            if (sActionName === "loadDocumentAISchema") {
                oPayload.schemaJson = sContent;
            } else {
                oPayload.edmxContent = sContent;
            }

            this.getView().setBusy(true);

            oModel.callFunction("/" + sActionName, {
                method: "POST",
                urlParameters: oPayload,
                success: function (oData) {
                    that.getView().setBusy(false);
                    MessageBox.success(oData.message || "Operation successful");
                    that.getView().getModel().refresh();
                },
                error: function (oError) {
                    that.getView().setBusy(false);
                    MessageBox.error("Error: " + (oError.message || oError.responseText));
                }
            });
        },
        */
        _callAction: async function (sActionName, sContent) {
            const oModel = this.getView().getModel();

            const oAction = oModel.bindContext(`/${sActionName}(...)`);
            oAction.setParameter("countryCode", this._sCountryCode);

            if (sActionName === "loadDocumentAISchema") {
                oAction.setParameter("schemaJson", sContent);
            } else {
                oAction.setParameter("edmxContent", sContent);
            }

            this.getView().setBusy(true);

            try {
                await oAction.execute();
                const result = oAction.getBoundContext().getObject();

                this.getView().setBusy(false);
                MessageBox.success(result.message || "Operation successful");

                oModel.refresh();  // reload bindings
            } catch (e) {
                this.getView().setBusy(false);
                MessageBox.error("Error: " + e.message);
            }
        },


        // Formatter functions for the view
        formatter: {
            getODataMapping: function (sDocField, sFieldType, mMappings) {
                if (!sDocField || !sFieldType || !mMappings) return "";
                var key = sDocField + "_" + sFieldType;
                return mMappings[key] || "";
            },
            getTransformation: function (sDocField, sFieldType, mTransformations) {
                if (!sDocField || !sFieldType || !mTransformations) return "";
                var key = sDocField + "_" + sFieldType;
                return mTransformations[key] || "";
            }
        },

        // Event handlers for mapping changes
        onMappingChange: function (oEvent) {
            var oSelectedItem = oEvent.getParameter("selectedItem");
            if (!oSelectedItem) return;

            var sNewValue = oSelectedItem.getKey();
            var oContext = oEvent.getSource().getBindingContext("mappingModel");
            var sDocField = oContext.getProperty("documentAIField_fieldName");
            var sFieldType = oContext.getProperty("documentAIField_fieldType");
            var key = sDocField + "_" + sFieldType;

            var oViewModel = this.getView().getModel("viewModel");
            var mappings = oViewModel.getProperty("/mappings");
            mappings[key] = sNewValue;
            oViewModel.setProperty("/mappings", mappings);
        },

        onTransformationChange: function (oEvent) {
            var sNewValue = oEvent.getParameter("value");
            var oContext = oEvent.getSource().getBindingContext("mappingModel");
            var sDocField = oContext.getProperty("documentAIField_fieldName");
            var sFieldType = oContext.getProperty("documentAIField_fieldType");
            var key = sDocField + "_" + sFieldType;

            var oViewModel = this.getView().getModel("viewModel");
            var transformations = oViewModel.getProperty("/transformations");
            transformations[key] = sNewValue;
            oViewModel.setProperty("/transformations", transformations);
        },

        /*
        onSave: function () {
            try {
                var that = this;
                var oTable = this.byId("mappingTable");
                if (!oTable) {
                    MessageBox.error("Table not found");
                    return;
                }
                var oMappingModel = oTable.getModel("mappingModel");
                if (!oMappingModel) {
                    MessageBox.error("Mapping model not found");
                    return;
                }
                var aItems = oMappingModel.getData().items;

                var oViewModel = this.getView().getModel("viewModel");
                var mappings = oViewModel.getProperty("/mappings") || {};
                var transformations = oViewModel.getProperty("/transformations") || {};
                var sCountryCode = this._sCountryCode;

                // Prepare payload
                var aConfigData = aItems.map(function (item) {
                    var sFieldName = item.documentAIField_fieldName;
                    var sFieldType = item.documentAIField_fieldType;
                    var key = sFieldName + "_" + sFieldType;

                    return {
                        fieldName: sFieldName,
                        fieldType: sFieldType,
                        visible: item.visible,
                        mandatory: item.mandatory,
                        odataFieldName: mappings[key] || null,
                        transformation: transformations[key] || null
                    };
                });

                var sConfiguration = JSON.stringify(aConfigData);

                this.getView().setBusy(true);
                var oModel = this.getView().getModel();

                oModel.callFunction("/saveConfiguration", {
                    method: "POST",
                    urlParameters: {
                        countryCode: sCountryCode,
                        configuration: sConfiguration
                    },
                    success: function (oData) {
                        that.getView().setBusy(false);
                        MessageBox.success("Configuration saved successfully");
                    },
                    error: function (oError) {
                        that.getView().setBusy(false);
                        MessageBox.error("Error saving configuration: " + (oError.message || oError.responseText));
                    }
                });
            } catch (e) {
                MessageBox.error("Error in onSave: " + e.message);
                console.error(e);
            }
        },
        */
        onSave: async function () {
            try {
                const oTable = this.byId("mappingTable");
                if (!oTable) {
                    MessageBox.error("Table not found");
                    return;
                }

                const oMappingModel = oTable.getModel("mappingModel");
                if (!oMappingModel) {
                    MessageBox.error("Mapping model not found");
                    return;
                }

                const aItems = oMappingModel.getData().items || [];

                const oViewModel = this.getView().getModel("viewModel");
                const mappings = oViewModel.getProperty("/mappings") || {};
                const transformations = oViewModel.getProperty("/transformations") || {};

                const sCountryCode = this._sCountryCode;

                // Prepare configuration array
                const aConfigData = aItems.map(item => {
                    const key = item.documentAIField_fieldName + "_" + item.documentAIField_fieldType;
                    return {
                        fieldName: item.documentAIField_fieldName,
                        fieldType: item.documentAIField_fieldType,
                        visible: item.visible,
                        mandatory: item.mandatory,
                        odataFieldName: mappings[key] || null,
                        transformation: transformations[key] || null
                    };
                });

                // Convert array to JSON string
                const sConfiguration = JSON.stringify(aConfigData);

                const oModel = this.getView().getModel();
                this.getView().setBusy(true);

                // --- ODATA V4: CALL ACTION ---
                const oAction = oModel.bindContext("/saveConfiguration(...)");

                oAction.setParameter("countryCode", sCountryCode);
                oAction.setParameter("configuration", sConfiguration);

                try {
                    await oAction.execute();  // sends body JSON to CAP

                    const result = oAction.getBoundContext().getObject();
                    this.getView().setBusy(false);

                    MessageBox.success(result.value || "Configuration saved successfully");

                    // Refresh view bindings
                    oModel.refresh();

                } catch (err) {
                    this.getView().setBusy(false);
                    MessageBox.error("Error saving configuration: " + err.message);
                }

            } catch (e) {
                MessageBox.error("Error in onSave: " + e.message);
                console.error(e);
            }
        },


        _saveMappings: function (mappings, transformations, sCountryCode) {
            // Deprecated, logic moved to onSave
        },

        onAddCustomField: function () {
            var that = this;
            if (!this._oNewFieldDialog) {
                this._oNewFieldDialog = new sap.m.Dialog({
                    title: "Add Custom Field",
                    content: [
                        new sap.m.VBox({
                            class: "sapUiSmallMargin",
                            items: [
                                new sap.m.Label({ text: "Field Name", labelFor: "newFieldName" }),
                                new sap.m.Input("newFieldName", { placeholder: "e.g. invoiceNumber" }),
                                new sap.m.Label({ text: "Field Type", labelFor: "newFieldType", class: "sapUiSmallMarginTop" }),
                                new sap.m.Select("newFieldType", {
                                    width: "100%",
                                    items: [
                                        new sap.ui.core.Item({ key: "header", text: "Header" }),
                                        new sap.ui.core.Item({ key: "lineItem", text: "Line Item" })
                                    ]
                                })
                            ]
                        })
                    ],
                    beginButton: new sap.m.Button({
                        text: "Add",
                        type: "Emphasized",
                        press: function () {
                            var sName = sap.ui.getCore().byId("newFieldName").getValue();
                            var sType = sap.ui.getCore().byId("newFieldType").getSelectedKey();
                            if (sName && sType) {
                                that._addNewField(sName, sType);
                                that._oNewFieldDialog.close();
                            } else {
                                sap.m.MessageToast.show("Please fill all fields");
                            }
                        }
                    }),
                    endButton: new sap.m.Button({
                        text: "Cancel",
                        press: function () {
                            that._oNewFieldDialog.close();
                        }
                    })
                });
                this.getView().addDependent(this._oNewFieldDialog);
            }
            this._oNewFieldDialog.open();
        },

        _addNewField: function (sName, sType) {
            var oTable = this.byId("mappingTable");
            var oModel = oTable.getModel("mappingModel");
            if (!oModel) {
                oModel = new sap.ui.model.json.JSONModel({ items: [] });
                oTable.setModel(oModel, "mappingModel");
            }
            var aData = oModel.getData().items || [];

            // Check for duplicates
            var bExists = aData.some(function (item) {
                return item.documentAIField_fieldName === sName && item.documentAIField_fieldType === sType;
            });

            if (bExists) {
                sap.m.MessageToast.show("Field already exists");
                return;
            }

            aData.push({
                documentAIField_fieldName: sName,
                documentAIField_fieldType: sType,
                visible: true,
                mandatory: false
            });
            oModel.setProperty("/items", aData);
        }
    });
});
