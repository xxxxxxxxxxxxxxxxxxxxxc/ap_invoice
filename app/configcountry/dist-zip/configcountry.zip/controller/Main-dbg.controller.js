sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast"
], (Controller, MessageToast) => {
    "use strict";

    return Controller.extend("configcountry.controller.Main", {
        onInit() {
        },
        onSelectionChange: function (oEvent) {
            var oItem = oEvent.getParameter("listItem");
            var oContext = oItem.getBindingContext();
            var sCode = oContext.getProperty("code");

            this.getOwnerComponent().getRouter().navTo("Detail", {
                countryCode: sCode
            });
        },

        onAddCountry: function () {
            // Simple dialog to create a new country
            // In a real app, use a Fragment. Here using simple JS for speed.
            var that = this;
            var oDialog = new sap.m.Dialog({
                title: "New Country",
                type: "Message",
                content: [
                    new sap.m.Label({ text: "Country Code (2 chars)", labelFor: "code" }),
                    new sap.m.Input("code", { maxLength: 2, width: "100%" }),
                    new sap.m.Label({ text: "Country Name", labelFor: "name" }),
                    new sap.m.Input("name", { width: "100%" })
                ],
                beginButton: new sap.m.Button({
                    type: "Emphasized",
                    text: "Create",
                    press: function () {
                        var sCode = sap.ui.getCore().byId("code").getValue();
                        var sName = sap.ui.getCore().byId("name").getValue();

                        if (!sCode || !sName) {
                            MessageToast.show("Please fill all fields");
                            return;
                        }

                        // Create entry via OData
                        var oModel = that.getView().getModel();
                        const oListBinding = oModel.bindList("/Countries");

                        const oContext = oListBinding.create({
                            code: sCode,
                            name: sName,
                            active: true
                        });

                        oContext.created().then(() => {
                            MessageToast.show("Country created!");

                            that.getOwnerComponent().getRouter().navTo("Detail", {
                                countryCode: sCode
                            });
                        }).catch((err) => {
                            MessageToast.show("Error creating country");
                            console.error(err);
                        });
                        /*
                        var oModel = that.getView().getModel();
                        oModel.create("/Countries", {
                            code: sCode,
                            name: sName,
                            active: true
                        }, {
                            success: function () {
                                MessageToast.show("Country created");
                                oDialog.close();
                                // Navigate to detail
                                that.getOwnerComponent().getRouter().navTo("Detail", {
                                    countryCode: sCode
                                });
                            },
                            error: function () {
                                MessageToast.show("Error creating country");
                            }
                        });
                        */
                    }
                }),
                endButton: new sap.m.Button({
                    text: "Cancel",
                    press: function () {
                        oDialog.close();
                    }
                }),
                afterClose: function () {
                    oDialog.destroy();
                }
            });

            oDialog.open();
        }
    });
});